# My Neovim Config
Simple NeoVim config inspired by theprimeagen's video on writing a config from scratch

## How to Setup
1. Download and install Packer.Neovim
2. Run 'PackerSync' command in Neovim
